function plotDt(InvPosiResu, textTime)
%% ����˵��
%���ܣ��������ٱ仯
numRow = 8;
numColumns = 4;

count = 0;
for i = 1:length(textTime)+1
    count = count + 1;
    if(i == 4)
        continue;
    elseif(i > 4)
        i = i-1;
    end
    r = ceil(count / numColumns);
    c = mod(count-1, numColumns) + 1;
    h = subplot(numRow, numColumns, count);

    % ��������
    x1 = InvPosiResu.PositResu{i,1}.ObsData.ST./3600;
    y1 = InvPosiResu.PositResu{i,1}.ObsData.T;
    x2 = InvPosiResu.PositResu{i,2}.ObsData.ST./3600;
    y2 = InvPosiResu.PositResu{i,2}.ObsData.T;

    scatter(x1, y1, ...
        1, 'filled', 'MarkerFaceColor', hex2rgb('#379FB4'), 'MarkerFaceAlpha', 1, 'MarkerEdgeAlpha', 1); hold on
    scatter(x2, y2, ...
        1, 'filled', 'MarkerFaceColor', hex2rgb('#DB498E'), 'MarkerFaceAlpha',  1, 'MarkerEdgeAlpha', 1); 
    
    % ����������
    box on
    sy = floor(min([y1;y2])*10)/10;
    ey = ceil(max([y1;y2])*10)/10;
    ylim(sy:ey-sy:ey);
    yticks(sy:ey-sy:ey);

    sx = floor(min(x1));
    ex = ceil(max(x1));
    xlim(sx:ex-sx:ex);
    xticks(sx:ex-sx:ex);

    ytickformat('%.1f');
    if(r == 4 && c == 1)
        ylabel('Temperature (\circC)','Position',[15 8.2]);
    end
    if(r == 8 && c == 2)
        xlabel('Observation time (h)','Position',[39 5.45]);
    end

    % ��ͼ��С����
    xBase = 0.12; yBase = 0.88;
    xDelta = 0.22; yDelta = 0.113;
    xWide = 0.15; yHigh = 0.06; 
    set(h,'position',[xBase+(c-1)*xDelta yBase-(r-1)*yDelta xWide yHigh])
end

% ��ע
legend('CTD','GLORYS12','position',[0.8 0.86 0.1 0.1],'Box','off');

% ͼƬ��С����
set(gcf,'Units','centimeter','Position',[0 0 9 12]);